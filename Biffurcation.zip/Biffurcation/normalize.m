function vector = normalize(aVector)
vector = aVector/norm(aVector);
end